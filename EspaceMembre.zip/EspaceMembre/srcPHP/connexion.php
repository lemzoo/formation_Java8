<?php 

// Connexion � la base de donn�es
try{
	$bdd = new PDO("mysql:host=localhost;dbname=ESPACE_MEMBRE;charset=utf8", "root", "root");
}
catch(Exception $e){
	die("Erreur : ".$e->getMessage());
}
// Hachage du mot de passe
$passwordHache = sha1($_POST["passwordSaisi"]);
$emailSaisi = $_POST["emailSaisi"];
$connexionAuto =  $_POST["connexionAuto"];

// V�rification des identifiants
$req = $bdd->prepare("SELECT idMembre FROM membres WHERE (emailMembre = :email AND passwordMembre = :pass)");
$req->execute(array(
    "email" => $emailSaisi,
    "pass" => $passwordHache)
	);

$resultat = $req->fetch();

if (!$resultat){
    echo "Mauvais identifiant ou mot de passe !";
}
else{
    session_start();
    $_SESSION["id"] = $resultat["idMembre"];
    $_SESSION["email"] = $emailSaisi;
    echo "Vous �tes connect� !";
    if(!$connexionAuto){
    	echo "Pas de connexion automatique";
    }
    else{
    	//On set les cookies
    	setcookie('email', $emailSaisi, time() + 365*24*3600, null, null, false, true);
    	setcookie('passwordHache', $passwordHache, time() + 365*24*3600, null, null, false, true);
    	
       	echo "Connexion automatique demand�e";
    }
}