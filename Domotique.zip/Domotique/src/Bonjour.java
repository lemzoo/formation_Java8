/**
 * Class Bonjour pour le test de l'environnement Eclipse
 * 
 * date : 09-06-2016
 * 
 * @author Eric
 *
 */
public class Bonjour {
	public static void main(String args[]) {
		System.out.println(
				"Bien le bonjour de toute la classe Eric.\nVoici le texte que vous avez pass� en param�tre " + args[0]);
	}
}